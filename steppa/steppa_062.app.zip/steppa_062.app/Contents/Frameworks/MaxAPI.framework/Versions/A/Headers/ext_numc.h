#ifndef _EXT_NUMC_H_
#define _EXT_NUMC_H_

// 	NOTE: This file is obsolete.

#endif /* _EXT_NUMC_H_ */
